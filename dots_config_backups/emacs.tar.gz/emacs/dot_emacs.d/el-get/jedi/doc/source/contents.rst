===========================
 Jedi.el document contents
===========================

.. toctree::

   index
   deprecation
   changelog
